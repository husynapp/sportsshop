
/**
 * Write a description of class Customer here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Customer
{
     double customerMoney;
     
     public Customer(){
        
         customerMoney= 500.00;
         
        }
        
     public void setMoney (double moneyPaid){
        customerMoney = customerMoney- moneyPaid;
        }  
        
     public double showMoney(){
        return this.customerMoney;
        }   
}




