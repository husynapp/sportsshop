
public class Shop
{
    double balance;
    
    
    public Shop()
    {
        
       this.balance = 500.00;
            
    }
    

    public double addMoney(double custMoney){
        balance += custMoney;
        return balance;
    }
    
    public double showShopBalance (){
        return balance;
    }
   
    public void resetBalance(){
        balance = 500.00;
    }
}
