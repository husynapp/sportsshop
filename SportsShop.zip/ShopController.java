import java.util.*;
public class ShopController

    {
        List<Item> searchResult;
        protected Item itemObject = new Item();
        protected Item footballReset = new Item("FB100","World Cup Football", 149.99, "Original Telstar Football that was"+
                                   " used in the 2018 FIFA World Cup", 5);
        protected Department departmentObject = new Department();
        protected Shop shopOnject = new Shop();
        protected Basket basketObject = new Basket();
        protected Customer custObject = new Customer();
    public ShopController(){
        
        System.out.println("");
        System.out.println("================================================");
        System.out.println("================================================");
        System.out.println("==========Sportmaaaaaaaaaaaaaaaaart=============");
        System.out.println("================================================");
        System.out.println("====WELCOME TO SPORTMART, ONE STOP SPORT SHOP===");
        System.out.println("                 _...----.._                 ");
        System.out.println("             ,:':::::.      `>.               ");
        System.out.println("            ,' |:::::;'      |:::.            ");
        System.out.println("           /    `'::'       :::::'\'           ");
        System.out.println("          /         _____     `::;'\'          ");
        System.out.println("         :         /:::::'\'      `  :         ");
        System.out.println("         | ,.     /::SMS::'\'        |         ");
        System.out.println("         |;:::.   `::::::;'          |         ");
        System.out.println("         ::::::     `::;'      ,.   ;         ");
        System.out.println("         '\':::'               ,:::/          ");
        System.out.println("          '\'                 '\':/           ");
        System.out.println("            `.     ,:.        :;'            ");
        System.out.println("              `-.::::::..  _.''              ");
        System.out.println("                 ```----'''                  ");

        System.out.println("Please get started with requesting what items are available");
        System.out.println("for that you can say 'Open Shop', 'Show items' then select " +
                            "\n the item you required"+ 
                            "Available commands are: " + "\n exit, help, open store, show items, "+
                            "buy items, show stock, show total, show balance, and restock");
        System.out.println("");
        
        Scanner local_in = new Scanner(System.in);
        Boolean local_isApplicationRunning = true;
        while(local_isApplicationRunning) {
            
            System.out.println("> ");
            String local_inputLine = local_in.nextLine();
            
            if(local_inputLine.equalsIgnoreCase("exit")){
                System.out.println( this.exitText());
                local_isApplicationRunning = false;
            }else if(local_inputLine.equalsIgnoreCase("help")){
                System.out.println( this.helpText());
            }else if(local_inputLine.equalsIgnoreCase("open store")){
                System.out.println( this.openStore());
            }else if(local_inputLine.equalsIgnoreCase("show items")){
                System.out.println( this.showItems());
            // }else if(local_inputLine.equalsIgnoreCase("buy something")){
                // System.out.println( this.sellItem());
            }else if(local_inputLine.equalsIgnoreCase("Buy items")){
                System.out.println("Please select an Item from product list\n");
                //if(local_inputLine.equalsIgnoreCase("FB100")){
                   // String x = "FB100";
                    System.out.println(searchByID(local_in.nextLine()));
              
            //}else if (local_inputLine.equalsIgnoreCase("show stock")){
               // System.out.println( this.getResult());
            }else if(local_inputLine.equalsIgnoreCase("show total")){
                System.out.println( this.showBasketTotal());
            }else if (local_inputLine.equalsIgnoreCase("show balance")){
                System.out.println( this.showCustBalance());
            }else if (local_inputLine.equalsIgnoreCase("restock")){
                System.out.println( this.reStockWFootball());
            }
        
        }
        
    }
    protected String exitText(){
        return "Thanks for coming, see you again";
    }
    protected String helpText(){
        return "Available commands are: exit, help, open store, show items, "+
                            "buy items, show total, show balance, and restock";
    }
    protected String openStore(){
        return "Store is now open, you may go ahead and look and purchase items";
    }
    protected String showItems(){
        for(int i = 0; i <departmentObject.entries.size(); i++){
            System.out.println(departmentObject.entries.get(i).getProductDetail());
        }
        return "End of list";
    }
    // protected String sellItem(){
        // Department items = new Department();
        // Item stock = new Item();
        // int x = stock.getStock()-1;
        // for(int i=0; i <items.entries.size(); i++){
            // items.entries.get(i).setStock(x);
        // }
        // return null;
    // }
    

    public List<Item> searchByID(String itemID){
        List<Item> searchResult = new ArrayList<>();
        
        List<Item> listToSearchThrough = departmentObject.getEntries();
        
        int limit = listToSearchThrough.size();
        
        for (int i=0; i<limit; i++){
            Item products = (listToSearchThrough.get(i));
            String productID = (products.getID());
            if(productID.equalsIgnoreCase(itemID)){
                searchResult.add(products);
                System.out.println(products);
                int x = products.getStock();
                products.setStock(x-=1);
                System.out.println("You have succesfully added " +
                products.getName() + "\nTo the basket, here are the remaining stock "+
                products.getProductDetail());
                double y= products.getPrice();
                basketObject.addToCost(y);
                custObject.setMoney(y);
                               
            }   
        }
        // if (productID!=itemID){
               // System.out.println("Incorrect product ID entered, Please enter correct ID to add to bakset");
        // }
        return searchResult;
        
    
    }
    //public List getResult(){
    //    return searchResult;
    //}
    public String showBasketTotal (){
        double x = basketObject.totalCost();
        return  "Total value of the items addes is: £"+ x;
    }
    public String showCustBalance(){
        double x = custObject.showMoney();
        return "Currently you have : £" + x;
    }
    public String reStockWFootball(){
        List x = departmentObject.getEntries();
        x.set(0,footballReset);
        return "World Cup Football were restocked";
    }
    }

