public class Basket
{
    double cost;
    
    public Basket(){
    
            cost=0;
    
    }
    
    
    public void addToCost(double itemCost){
       cost += itemCost;
    
    }
    
    
    public double totalCost(){
        return cost;
    }
}
